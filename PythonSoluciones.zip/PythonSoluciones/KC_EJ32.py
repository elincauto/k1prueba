#coding: utf-8

"""
---
KC_EJ32
Crear una clase Módulo con los siguientes atributos: 
Listado_alumnos, fecha_inicio, fecha_fin. 

El listado de alumnos deberá ser tipo Lista y contener objetos de tipo Alumno creado en el ejercicio KC_EJ31.

En la misma clase Módulo deberá implementar métodos para 
agregar objetos Alumno a la Lista
buscar un alumno 
mostrar todos los alumnos con estatus_inscrito == True.
---
"""
import time

class Alumno:
	#atributos con valores iniciales
	numero_matricula = 0
	nombre = ""
	apellido = ""
	correo_electronico = ""
	estatus_inscrito = False

	#constructores
	def __init__(self, numero_matricula, nombre, apellido, correo_electronico, estatus_inscrito):	
		self.numero_matricula = numero_matricula
		self.nombre = nombre
		self.apellido = apellido
		self.correo_electronico = correo_electronico
		self.estatus_inscrito = estatus_inscrito

class Modulo:
	#atributos
	listado_alumnos = []
	fecha_inicio = time.strftime("%x")
	fecha_fin = time.strftime("%x")

	#constructor por default, iniciliza el listado de alumnos (10 objetos ahora fijos, se asume que se leerán de una BD, o un servicio)
	def __init__(self):
		for a in range(0, 10):
			self.listado_alumnos.append(Alumno( a, "Alumno " + str(a), "Apellido " + str(a), "correo"+str(a)+"@gmail.com", True))

	#método para agregar nuevos alumnos 		
	def agregar(self, alumno):
		self.listado_alumnos.append(alumno)			

	#método para buscar alumnos por matrícula	
	def buscar(self, matricula):
		encontro = False
		for a in self.listado_alumnos:
			if a.numero_matricula == matricula:
				print "Se encontró " + a.nombre + " " + a.correo_electronico
				encontro = True
				break
			
		if encontro == False:
			print "No se encontraron alumnos con esa matrícula"
		
		 		
	def mostrar_inscritos(self):
		for a in self.listado_alumnos:
			if a.estatus_inscrito:
				print str(a.numero_matricula) + "-"+"Nombre:" + a.nombre + " " + a.apellido + ", correo: " + a.correo_electronico 		
