﻿#coding: utf-8

"""
---
KC_EJ28
Crear un programa que contenga una función pintar_rectangulo(lado, figura). 
Esta función deberá pintar en la página un cuadrilátero de lado x lado con la figura proporcionada.
---
"""
def pintar_rectangulo(lado, figura):
	print(figura*lado) #Primera línea
	for i in range(lado-2): 
		print(figura+' '*(lado-2)+figura) #figura, N espacios, figura
	print(figura*lado) #última línea

#inicia programa
lado = input("Dame la altura del rectángulo: ")
figura = raw_input("¿Con qué figura quieres tu cuadrado?: ")
pintar_rectangulo(lado, figura)