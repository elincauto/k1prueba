#coding: utf-8

"""
---
KC_EJ15
Crear un programa que reciba los el nombre y las calificaciones de 3 personas. 
Para cada persona deberá guardar la información en una tupla. 
El programa no mostrará resultados de salida.
---
"""

#opción 1, hacer todo de uno en uno
print("----------")
nombre_1 = raw_input("Nombre de la persona 1 >>")
nota1_1 = raw_input("Nota 1 de la persona 1 >>")
nota2_1 = raw_input("Nota 2 de la persona 1 >>")
nota3_1 = raw_input("Nota 3 de la persona 1 >>")
persona_1 = (nombre_1, nota1_1, nota2_1, nota3_1)
print("----------")
nombre_2 = raw_input("Nombre de la persona 2 >>")
nota1_2 = raw_input("Nota 1 de la persona 2 >>")
nota2_2 = raw_input("Nota 2 de la persona 2 >>")
nota3_2 = raw_input("Nota 3 de la persona 2 >>")
persona_2 = (nombre_2, nota1_2, nota2_2, nota3_2)
print("----------")
nombre_3 = raw_input("Nombre de la persona 3 >>")
nota1_3 = raw_input("Nota 1 de la persona 3 >>")
nota2_3 = raw_input("Nota 2 de la persona 3 >>")
nota3_3 = raw_input("Nota 3 de la persona 3 >>")
persona_3 = (nombre_3, nota1_3, nota2_3, nota3_3)
print("----------")
print("Fin de la captura")

#Otra es leer un texto con un formato, por ejemplo separado con comas
