#coding: utf-8

"""
---
KC_EJ08
Crear un programa que reciba un número entero y muestre si es par o impar, positivo o negativo, o cero.
---
"""

num = int(raw_input("Ingresa un número entero >>"))


#solución 1, combinatoria
if num > 0 and num%2==0:
	print("Número par positivo")
elif num > 0 and num%2!=0:
	print("Número impar positivo")
elif num < 0 and num%2==0:
	print("Número par negativo")
elif num < 0 and num%2!=0:
	print("Número impar negativo")
else:
	print("CERO")


#solución 2, if anidados
if num == 0:
	print("CERO")
else:
	if num > 0:
		if num%2==0:
			print("Número par positivo") 
		else:
			print("Número impar positivo") 
	else:
		if num%2==0:
			print("Número par negativo") 
		else:
			print("Número impar negativo") 	
