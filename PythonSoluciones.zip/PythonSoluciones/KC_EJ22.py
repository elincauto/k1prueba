#coding: utf-8

"""
---
KC_EJ22
Crear un programa que reciba los nombres y edades de 10 personas. 
Mostrar únicamente los nombres de las personas que tienen derecho a votar (mayores a 18 años).
---
"""
diccionario = {}
lista = []

contador = 10
while contador != 0:
	nombre = raw_input("Introduce el nombre: ")
	edad = input("Introduce su edad: ")
	diccionario[nombre] = edad
	contador = contador - 1

for i,j in diccionario.iteritems():
	if j >= 18:
		lista.append(i)

print "Pueden Votar: " 
for a in lista: 
	print a
