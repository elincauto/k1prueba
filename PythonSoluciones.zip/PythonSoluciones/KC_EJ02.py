#coding: utf-8

"""
---
KC_EJ02
Crea un programa que solicite dos números y muestre los resultados de todas sus operaciones aritméticas. 
---
"""

#entrada como texto, se puede leer como número directamente con input
num1 = raw_input("Valor del primer número >>")
num2 = raw_input("Valor del segundo número >>")

#posible solución, castear a número para hacer la operación y después regresar a String
print(num1+" + "+num2+" = " + str(int(num1)+int(num2)))

#Otra solución, crear una variable con tipo string y otra con valor numérico
int_num1 =int(num1)
int_num2 =int(num2)

#convertimos a textos los resultados para poder concatenarlos
print(num1+" - "+num2+" = " + str(int_num1-int_num2))

print(num1+" X "+num2+" = " + str(int_num1*int_num2))

print(num1+" / "+num2+" = " + str(int_num1/int_num2))

print(num1+" a la potencia de "+num2+" = " + str(int_num1**int_num2))

print(num1+" % "+num2+" = " + str(int_num1%int_num2))