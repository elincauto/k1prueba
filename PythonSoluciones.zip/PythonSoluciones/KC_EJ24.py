#coding: utf-8

"""
---
KC_EJ24
Modificar el programa KC_EJ23 para que muestre los resultados ordenados por la media, de forma descendente.
---
"""
import operator

nombre = ""
total = 0
diccionario = {}
media = 0 
final = {}

while True: #no sabemos cuántas personas serán. Dejamos ciclo infinito y lo controlamos con break
	nombre = raw_input("Introduce el nombre de una persona ('terminar' para finalizar la captura) : ")
	total = 0;
	if nombre == "terminar": #termina la captura
		break
	for i in range(1,4): #leemos las notas de la persona
		notas = input("Introduce nota "+ str(i) + " de " +  nombre + ": ")
		total  = total + notas #acumulamos la nota
	diccionario[nombre] = total/3 #calculamos la media y lo asociamos a la persona

	
print "*** NOTAS MEDIAS ***" 

#definimos la función de ordenamiento, indicando que deseamos ordenar por valor (el getter del elemento 1)
final = sorted(diccionario.items(), key=operator.itemgetter(1))

for a in final:
	print "",a[0],"-",a[1]
