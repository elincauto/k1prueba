#coding: utf-8

"""
---
KC_EJ25
Crear un programa que contenga un número aleatorio del 1 al 100, sin mostrarlo, y permitir que el usuario intente adivinarlo. 
El usuario solamente tendrá 5 oportunidades, 
en cada oportunidad fallida se le darán pistas para saber si debe intentar con un número mayor o menor.
---
"""
import random
numero = random.randint(1, 101) #generamos el número aleatorio a adivinar, uno por partida

oportunidades = 5 #le damos N oportunidades

if oportunidades == 0: #validamos que aún le queden oportunidades
	print "¡Se terminaron las oportunidades! :("
while oportunidades != 0: 
	print "Te quedan %d oportunidades" % oportunidades
	respuesta = input("Adivina el número: ")	
	if numero == respuesta: #atinó, fin del juego
		print "¡Ganaste, YEI! :D"
		break
	else:
		oportunidades = oportunidades - 1 #le quitamos una oportunidad y le damos pistas 
		if numero < respuesta:
			print "¡Menos!"		
		elif numero > respuesta:
			print "¡Más!"
		