#coding: utf-8

"""
---
KC_EJ01
Crea un programa por el cual se solicite al usuario el radio de un círculo. 
El programa deberá calcular y mostrar el área.
---
"""

#Se puede usar la biblioteca math o directamente la constante 3.14159
import math
#se puede leer como número directamente con input
radio = raw_input("Radio del círculo >>")
#convertimos el radio a valor de punto flotante
area = math.pi*(float(radio)**2)

#Salida solo concatenando, convertimos a Texto el valor del resultado
print("El área es " + str(area))

#Salida limitando el resultado a dos decimales
print("El área es %.2f" % area)

