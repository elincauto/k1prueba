#coding: utf-8

"""
---
KC_EJ33
Usando las clases de los ejercicios KC_EJ31 y KC_EJ32, crear un programa que contenga una instancia de la clase Módulo, 
con instancias de alumnos predefinidos en init. El programa permitirá al usuario:
Ver todos los alumnos enrolados.
Buscar un alumno por matrícula.
---
"""
import time

class Alumno:
	#atributos con valores iniciales
	numero_matricula = 0
	nombre = ""
	apellido = ""
	correo_electronico = ""
	estatus_inscrito = False

	#constructores
	def __init__(self, numero_matricula, nombre, apellido, correo_electronico, estatus_inscrito):	
		self.numero_matricula = numero_matricula
		self.nombre = nombre
		self.apellido = apellido
		self.correo_electronico = correo_electronico
		self.estatus_inscrito = estatus_inscrito

class Modulo:
	#atributos
	listado_alumnos = []
	fecha_inicio = time.strftime("%x")
	fecha_fin = time.strftime("%x")

	#constructor por default, iniciliza el listado de alumnos (10 objetos ahora fijos, se asume que se leerán de una BD, o un servicio)
	def __init__(self):
		for a in range(0, 10):
			self.listado_alumnos.append(Alumno( a, "Alumno " + str(a), "Apellido " + str(a), "correo"+str(a)+"@gmail.com", True))

	#método para agregar nuevos alumnos 		
	def agregar(self, alumno):
		self.listado_alumnos.append(alumno)			

	#método para buscar alumnos por matrícula	
	def buscar(self, matricula):
		encontro = False
		for a in self.listado_alumnos:
			if a.numero_matricula == matricula:
				print "Se encontró " + a.nombre + " " + a.correo_electronico
				encontro = True
				break
			
		if encontro == False:
			print "No se encontraron alumnos con esa matrícula"
		
		 		
	def mostrar_inscritos(self):
		for a in self.listado_alumnos:
			if a.estatus_inscrito:
				print str(a.numero_matricula) + "-"+"Nombre:" + a.nombre + " " + a.apellido + ", correo: " + a.correo_electronico 		




def mostrar_menu():
	print "******Bienvenido*******"
	print "Seleccione una opción:"
	print "1) Ver todos los alumnos matriculados"
	print "2) Buscar a un alumno por matrícula"
	print "3) Salir"

modulo = Modulo()
opcion = 0
while opcion != 3:
	mostrar_menu()
	opcion = input()
	if opcion == 1:
		modulo.mostrar_inscritos()
	elif opcion == 2:
		matricula = input("Ingresa la matrícula a buscar:")
		modulo.buscar(int(matricula))
	else:
		print "Opción inválida"

print "Adios!"