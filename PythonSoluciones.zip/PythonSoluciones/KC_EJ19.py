#coding: utf-8

"""
---
KC_EJ19
Crear un programa que almacene 10 números dados por el usuario y muestre únicamente los pares.
---
"""

numeros = []

for indice in range(1,11):
	numeros.append( int(raw_input("Introduce el número " + str(indice) + " >>")))

mensaje = "Son pares "
for numero in numeros:
	if numero % 2 == 0:
		mensaje = mensaje + str(numero) 
		if(numero < 10): #agrego la coma "," para dar formato al mensaje de salida solamente si no es el último
			mensaje = mensaje + ", "

print(mensaje)

