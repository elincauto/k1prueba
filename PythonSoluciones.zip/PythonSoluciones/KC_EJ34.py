#coding: utf-8

"""
---
KC_EJ34
Crear las clases AlumnoRemoto y AlumnoPresencial, ambas subclases de la clase Alumno creada en el ejercicio KC_EJ31.

AlumnoRemoto deberá contar con los atributos numero_matricula, nombre, apellido, correo_electronico, estatus_inscrito, skype, huso_horario. 
Mientras que AlumnoPresencial deberá definir los atributos numero_matricula, nombre, apellido, correo_electronico, estatus_inscrito, numero_asiento. 
---
"""
class Alumno:
	#atributos con valores iniciales
	numero_matricula = 0
	nombre = ""
	apellido = ""
	correo_electronico = ""
	estatus_inscrito = False

	#constructores
	def __init__(self, numero_matricula, nombre, apellido, correo_electronico, estatus_inscrito):	
		self.numero_matricula = numero_matricula
		self.nombre = nombre
		self.apellido = apellido
		self.correo_electronico = correo_electronico
		self.estatus_inscrito = estatus_inscrito

class AlumnoRemoto(Alumno):
	skype = ""
	huso_horario = ""

class AlumnoPresencial(Alumno):
	numero_asiento = 0