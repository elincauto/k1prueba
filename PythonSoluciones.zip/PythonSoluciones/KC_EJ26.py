﻿#coding: utf-8

"""
---
KC_EJ26
Crear un programa con una función pintaFila() que arme las filas de una tabla html. 
Completar el programa con la estructura de una tabla e invocando a la función N veces, 
donde N es un valor introducido por el usuario.
---
"""

#función para pintar cada fila
def pintar_fila(n):
	for i in range(0,n):
		print "<tr><td></td></tr>"
	

#inicia el programa
veces = input("Introduce el número de filas: ")

#imprimimos la estructura de la tabla
print "<table>"
pintar_fila(veces) #llamamos a la función
print "</table>" 