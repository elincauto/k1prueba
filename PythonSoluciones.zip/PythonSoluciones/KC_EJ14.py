#coding: utf-8

"""
---
KC_EJ14
Crear un programa que reciba un texto y muestre su longitud

---
"""

texto = raw_input("Ingresa el texto >>")
#tan sencillo como usar el método len de un String
print("El texto " + texto + " tiene una longitud de " + str(len(texto)))