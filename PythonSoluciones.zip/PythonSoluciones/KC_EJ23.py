#coding: utf-8

"""
---
KC_EJ23
Crear un programa que reciba los el nombre y las calificaciones de N personas, mientras que el usuario no escriba “terminar”. 
Al terminar deberá mostrar la media de calificaciones de cada persona.
---
"""
import operator

nombre = ""
total = 0
diccionario = {}
media = 0 

while True: #no sabemos cuántas personas serán. Dejamos ciclo infinito y lo controlamos con break
	nombre = raw_input("Introduce el nombre de una persona ('terminar' para finalizar la captura) : ")
	total = 0;
	if nombre == "terminar": #termina la captura
		break
	for i in range(1,4): #leemos las notas de la persona
		notas = input("Introduce nota "+ str(i) + " de " +  nombre + ": ")
		total  = total + notas #acumulamos la nota
	diccionario[nombre] = total/3 #calculamos la media y lo asociamos a la persona
	

print "*** NOTAS MEDIAS ***" 

for a,b in diccionario.iteritems():
	print "",a,"-",b
