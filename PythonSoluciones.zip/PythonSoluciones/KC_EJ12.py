#coding: utf-8

"""
---
KC_EJ12
Crear un programa que reciba una letra e indique si es vocal o consonante.
---
"""

letra = raw_input("Dame la letra >>")

#comparo contra todas las vocales.
#otra posible solución sería tener una lista con las vocales y preguntar si la contiene
if letra == "a" or letra == "A" or letra == "e" or letra == "E" or letra == "i" or letra == "I" or letra == "o" or letra == "O" or letra == "u" or letra == "U":
	print(letra + " es vocal")
else: #ojo que no estamos validando si es número
	print(letra + " es consonante")