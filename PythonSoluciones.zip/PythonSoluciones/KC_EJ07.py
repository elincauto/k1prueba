#coding: utf-8

"""
---
KC_EJ07
Crea un programa que solicite tres notas y calcule su media. Dependiendo del valor de la media, mostrará si el resultado es Apto o No Apto.
---
"""

nota1 = int(raw_input("Nota 1 >>"))
nota2 = int(raw_input("Nota 2 >>"))
nota3 = int(raw_input("Nota 3 >>"))
media = (nota1+nota2+nota3)/3

#opción, notas en ciclo
media = 0
for i in range(0,3):
	media = media + int(raw_input("Nota " + str(i) + " >>"))
media = media / 3


if media >= 6:
	print("APTO")
else:
	print("NO APTO")
