#coding: utf-8

"""
---
KC_EJ13
Crear un programa que contenga una lista de 20 números y muestre un rango de la lista. 
El inicio y fin del rango serán introducidos por el usuario y el programa deberá validar que sean valores válidos.
---
"""

#lista predefinida
numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

inicio = int(raw_input("Inicio del rango a mostrar >>"))
fin = int(raw_input("Fin del rango a mostrar >>"))

if inicio > 0 and fin < len(numeros): #opción fin < 20:
	from_2_to_6 = numeros[inicio:fin] #usamos la capacidad de slice de python
	print(from_2_to_6)
else:
	print("Ese no es un rango válido")