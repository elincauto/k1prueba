#coding: utf-8

"""
---
KC_EJ20
Crear un programa que escriba la suma de los números del 1 a N, donde N será dado por el usuario.
---
"""

max = int(raw_input("Introduce el número máximo >>"))+1
suma = 0
res = ""

#opción con ciclo
for num in range(1,max):
	suma = suma + num
	res = res + str(num) 
	if num != max-1:
		res = res + " + "	

res = res + " = " + str(suma)
print(res)
