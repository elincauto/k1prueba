#coding: utf-8

"""
---
KC_EJ17
Crear un programa que contenga un diccionario con nombres y correos electrónicos. 
Solicitar el nombre de una persona y mostrar su correo electrónico. 
Indicar con un mensaje apropiado cuando no se encuentre un resultado válido.
---
"""


direcciones = {"Pedro":"pedro.picapiedra@gmail.com", "Pablo":"pmarmol123@gmail.com", "Bob": "bob@gmail.com"}

buscar = raw_input("Nombre a buscar >>")

#valido si el nombre ingresado se encuentra como llave en el diccionario
if direcciones.get(buscar) != None:
	print(direcciones.get(buscar))	
else:
	print("No he encontrado al elemento")

