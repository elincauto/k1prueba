#coding: utf-8

"""
---
KC_EJ09
Crea un programa que reciba una cantidad, y pregunte si desea convertirla de Euros a USD o de USD a Euros y muestre el resultado de la conversión.
---
"""

cantidad = raw_input("Ingrese la cantidad >>")
op = raw_input("¿Tu cantidad está en euros (EUR) o en dólares americanos (USD) >>")
res = 0.0

#validamos que las entradas no sean algo extraño
if op != "EUR" and op !=  "USD":
	print("No tengo opciones para el tipo de cambio seleccionado")
else: #si todo bien, convertimos
	if op == "EUR":
		res = float(cantidad)*1.06 
		print(cantidad + " EUR equivalen a " + str(res) + " USD")
	elif op == "USD":
		res = float(cantidad)/1.06
		print(cantidad + " USD equivalen a " + str(res) + " EUR")



