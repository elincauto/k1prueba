#coding: utf-8

"""
---
KC_EJ04
Crea un programa que solicite tres notas y muestre su media.
---
"""

#opción, nota a nota
nota1 = int(raw_input("Nota 1 >>"))
nota2 = int(raw_input("Nota 2 >>"))
nota3 = int(raw_input("Nota 3 >>"))

media = (nota1+nota2+nota3)/3

#opción, notas en ciclo
media = 0
for i in range(0,3):
	media = media + int(raw_input("Nota " + str(i) + " >>"))
media = media / 3

print("La media de las 3 notas es " + str(media))