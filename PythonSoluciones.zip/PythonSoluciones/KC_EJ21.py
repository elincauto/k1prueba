#coding: utf-8

"""
---
KC_EJ21
Crear un programa que reciba un número natural entero y muestre su tabla de multiplicar del 1 al 10.
---
"""


numero = input("Introduzca un numero para que se muestre su tabla de multiplicar: ")
#sin funciones, sin for
print numero,"X",1,"=",numero*1
print numero,"X",2,"=",numero*2
print numero,"X",3,"=",numero*3
print numero,"X",4,"=",numero*4
print numero,"X",5,"=",numero*5
print numero,"X",6,"=",numero*6
print numero,"X",7,"=",numero*7
print numero,"X",8,"=",numero*8
print numero,"X",9,"=",numero*9
print numero,"X",10,"=",numero*10

#opción con for
for i in range(1, 11):
	print numero,"X "+str(i)+" =",numero*i