#coding: utf-8

"""
---
KC_EJ11
Crear un programa que reciba 3 números e indique cuál es el mayor y el menor.
---
"""

num1 = raw_input("Dame el primer número >>")
num2 = raw_input("Dame el segundo número >>")
num3 = raw_input("Dame el tercer número >>")

mayor = 0
menor = 0

#intento descubrir si el primer número es mayor a los demás 
if num1 > num2 and num1 > num3:
	mayor = num1
#o si lo es el segundo	
elif num2 > num1 and num2 > num3:
	mayor = num2
#si no cayó en ninguna de las anteriores, no hay más qué preguntar, seguro el tercero es el mayor	
else:
	mayor = num3

#intento descubrir si el primer número es menor a los demás 
if num1 < num2 and num1 < num3:
	menor = num1
#o si lo es el segundo	
elif num2 < num1 and num2 < num3:
	menor = num2
#si no cayó en ninguna de las anteriores, no hay más qué preguntar, seguro el tercero es el menor	
else:
	menor = num3

print("El mayor es " + str(mayor) + " y el menor es " + str(menor))