#coding: utf-8

"""
---
KC_EJ05
Crear un programa que solicite el año y mes de nacimiento de dos personas, y muestre el resultado de compararlas
---
"""

#opción, leo mes y año uno a uno
anio_1 = raw_input("Año de nacimiento de la primera persona >>")
mes_1 = raw_input("Mes de nacimiento de la primera persona >>")

anio_2 = raw_input("Año de nacimiento de la segunda persona >>")
mes_2 = raw_input("Mes de nacimiento de la segunda persona >>")

#imprimo la comparación de mes y años
res = (anio_1 == anio_2) and (mes_1 == mes_2)
print(str(res))
