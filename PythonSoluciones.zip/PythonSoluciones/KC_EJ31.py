#coding: utf-8

"""
---
KC_EJ31
Crear una clase Alumno con los siguientes atributos: 
numero_matricula, nombre, apellido, correo_electronico, estatus_inscrito. 
La matrícula deberá ser numérica, mientras que correo_electronico, nombre y apellido como textos. 
El atributo estatus_inscrito deberá ser un valor booleano. 
---
"""
class Alumno:
	#atributos con valores iniciales
	numero_matricula = 0
	nombre = ""
	apellido = ""
	correo_electronico = ""
	estatus_inscrito = False

	#constructores
	def __init__(self, numero_matricula, nombre, apellido, correo_electronico, estatus_inscrito):	
		self.numero_matricula = numero_matricula
		self.nombre = nombre
		self.apellido = apellido
		self.correo_electronico = correo_electronico
		self.estatus_inscrito = estatus_inscrito

