#coding: utf-8

"""
---
KC_EJ10
Crear un programa que reciba un número del 1 al 7 y muestre el nombre de la película StarWars correspondiente.
---
"""

peli = raw_input("Dime el número de episodio de StarWars para saber su nombre >>")

if peli == "1" or peli == "I":
	print("StarWars I - La amenaza fantasma")
elif peli == "2" or peli == "II":
	print("StarWars II - El ataque de los clones")
elif peli == "3" or peli == "III":
	print("StarWars III - La vanganza de los Sith")
elif peli == "4" or peli == "IV":
	print("StarWars IV - Una nueva esperanza")
elif peli == "5" or peli == "V":
	print("StarWars V - El imperio contraataca")
elif peli == "6" or peli == "VI":
	print("StarWars VI - El regreso del Jedi")
elif peli == "7" or peli == "VII":
	print("StarWars VII - El despertar de la fuerza")
else:
	print("¡Paciencia padawan, esa no existe aún!")