#coding: utf-8

"""
---
KC_EJ03
Crea un programa que solicite una cantidad en Euros y muestre su equivalente en USD.
---
"""
#leemos cantidad 
cantidad = raw_input("Ingrese la cantidad en Euros >>")
#el tipo de cambio directo o lo podemos tener en alguna variable para facilitar el mantenimiento
res = float(cantidad)*1.06
#convertimos el resultado a texto para concatenar el mensaje a mostrar
print(cantidad + " EUR equivalen a " + str(res) + " USD")