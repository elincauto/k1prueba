﻿#coding: utf-8

"""
---
KC_EJ29
Modificar el programa KC_EJ24 (promedio de alumnos) de forma tal que el cálculo del promedio se realice a través de una función. 
---
"""
import operator
nombre = ""
total = 0
diccionario = {}
media = 0 
final = {}

#objetivo del ejercicio es el uso de funciones.

def captura_persona(nombre):
	for i in range(1,4): 
		notas = input("Introduce nota "+ str(i) + " de " +  nombre + ": ")
		total  = total + notas 
	diccionario[nombre] = total/3 

def imprime_notas:
	print "*** NOTAS MEDIAS ***" 
	final = sorted(diccionario.items(), key=operator.itemgetter(1))
	for a in final:
		print "",a[0],"-",a[1]

#inicia el programa
while True: 
	nombre = raw_input("Introduce el nombre de una persona ('terminar' para finalizar la captura) : ")
	total = 0;
	if nombre == "terminar": #termina la captura
		break
	captura_persona(nombre)

imprime_notas()

