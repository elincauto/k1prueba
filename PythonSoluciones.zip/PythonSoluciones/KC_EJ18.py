#coding: utf-8

"""
---
KC_EJ18
Crear un programa que muestre los números naturales del 1 al N, donde N será dado por el usuario.
---
"""

max = int(raw_input("Número máximo a mostrar >>"))

#opción 1 con for
for num in range(1,max):
	print(num)

#opción 1 con while
i = 1;
while i < max:
	print(i)
	i = i+1