#coding: utf-8

"""
---
KC_EJ16
Crear un programa que contenga una Lista de nombres. 
Solicitar un índice de la lista y mostrar el valor del índice. 
El programa deberá validar que el índice es válido.

---
"""

nombres = ["Pedro Picapiedra", "Pablo Marmol", "Bob Esponja", "Patricio"]

indice = int(raw_input("Índice a mostrar >>"))

if  indice < len(nombres):
	print(nombres[indice])
else:
	print("No cuento con ese índice")