#coding: utf-8

"""
---
KC_EJ06
Crea un programa que solicite dos números y muestre los resultados de aplicar comparaciones relacionales. 
---
"""
num1 = raw_input("Valor del primer número >>")
num2 = raw_input("Valor del segundo número >>")

#posible solución, convertir a número para hacer la operación y después regresar a String
print(num1+" < "+num2+" = " + str(int(num1)<int(num2)))

#Otra solución, crear una variable con tipo string y otra con valor numérico
int_num1 =int(num1)
int_num2 =int(num2)
print(num1+" > "+num2+" = " + str(int_num1>int_num2))

print(num1+" y "+num2+" son iguales = " + str(int_num1 == int_num2))

print(num1+" y "+num2+" son distintos = " + str(int_num1 != int_num2))
