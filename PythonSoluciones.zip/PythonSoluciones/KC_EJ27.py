﻿import sys

#coding: utf-8

"""
---
KC_EJ27
Crear un programa que contenga una función esPalindromo(texto) y determine si dicho texto es un palíndromo.
---
"""
#opción, con textos
def es_palindromo(texto):
    #Eliminamos los espacios
    texto = texto.replace(' ','')
    #Invertimos el texto
    texto_2 = list(reversed(texto))
    #Comparamos
    for a,b in zip(texto,texto_2):
        if a != b: #si no coincide cualquiera, no es palíndromo
            print 'Es palíndromo'
            return
    #Si logró salir del ciclo sin salir de la función, es palíndromo      
    print 'No es palíndromo'


"""Opción, con listas
lista = list(texo)
lista = lista.replace(' ','')
    for i in range(len(lista),0,-1):
        reverse.append(lista[i-1])
    if lista == reverse:
        print "Es palindromo"
    else:
        print "No es palindromo"
"""

txt = raw_input('Dime un texto para saber si es palíndromo: ')
es_palindromo(txt)
