#-*- coding: utf-8 -*-
from django.shortcuts import render
from photos.models import Photo


def home(request):
    """
    Esta función devuelve el home de mi página
    """
    photos = Photo.objects.all()
    return render(request, 'photos/home.html')

