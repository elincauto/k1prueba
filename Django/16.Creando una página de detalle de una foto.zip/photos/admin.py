from django.contrib import admin
from photos.models import Photo


admin.site.register(Photo)
